export class User {
  _id: number;
  name:string;
}